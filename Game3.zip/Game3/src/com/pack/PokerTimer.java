package com.pack;

public class PokerTimer implements Runnable {
	
	public void setText(String text){
		
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}