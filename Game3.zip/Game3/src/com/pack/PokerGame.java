package com.pack;

import java.util.ArrayList;


public class PokerGame {

	private Deck theDeck;
	private boolean isGameOver;


//	public PokerGame(){
//		theDeck = new Deck();
//		makePlayers();
//		isGameOver = false;
//		
//	}		
////	public void initPlayers(int n, int money){
////		for(int i = 0; i < n ; i++){
////			initPlayer(money);
////		}
////	}
////	
////	public void initPlayer(int money){
////		Player myPlayer = new Player(money, "Jerry", theDeck);
////	}
//	
//	private void makePlayers() {
//		Player player1 = new Player(500, "Chris", theDeck);
//		Player player2 = new Player(500, "Don", theDeck);
//		players = new ArrayList<Player>(2); //TODO Implement proper GUI
//		players.add(player1);
//		players.add(player2);
//	}
	


}
